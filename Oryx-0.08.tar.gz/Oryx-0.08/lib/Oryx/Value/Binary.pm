package Oryx::Value::Binary;
use base qw(Oryx::Value);

1;
