package Parent2;

use base qw(Oryx::Class);

our $schema = {
    attributes => [{
        name => 'parent2_attrib',
        type => 'String',
    }],
};

1;
