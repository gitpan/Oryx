package Class2;

use base qw(Oryx::Class);

our $schema = {
    attributes => [{
        name => 'attrib1',
        type => 'String',
    }],
};

1;
