package Oryx::DBM::Association;
use base qw(Oryx::Association);
1;
