package Oryx::Value::Oid;

# This is here to eventually support multi-column primary keys, if,
# indeed they're needed... something I can't guess at this stage.

use base qw(Oryx::Value);

1;
