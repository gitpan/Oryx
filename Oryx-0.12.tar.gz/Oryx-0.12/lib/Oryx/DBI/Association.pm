package Oryx::DBI::Association;
use base qw(Oryx::Association);
1;
